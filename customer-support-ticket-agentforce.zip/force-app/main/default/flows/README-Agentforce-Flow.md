# Auto-Launched Flow configuration

The source project specifies an Auto-Launched Flow named `Support_Ticket_Intellegence`.

## Variables

| Label | API Name | Type | Input/Output |
|---|---|---|---|
| Account Name | `varAccountName` | Text | Input |
| Account Id | `varAccountId` | Text | Output |
| Ticket Id | `varTicketId` | Text | Output |
| Priority Level | `varPriorityLevel` | Text | Output |
| Assigned Agent | `varAssignedTo` | Text | Output |
| Message | `varActionMessage` | Text | Output |

## Flow elements

1. Get Account
   - Object: Account
   - Name equals `varAccountName`
   - Sort by CreatedDate DESC
   - Store first record.

2. Store Account Id
   - `varAccountId = Get_Account.Id`

3. Get Ticket
   - Object: `Support_Ticket_Intelligence__c`
   - Customer equals `varAccountId`
   - Sort by CreatedDate DESC
   - Store first record.

4. Store Ticket Id
   - `varTicketId = Get_Ticket.Id`

5. Analyze Description
   - High: `urgent`, `not working`, `failure`
   - Medium: `issue`, `slow`, `delay`
   - Otherwise Low.

6. Set `varPriorityLevel`.

7. High Priority decision.

8. High priority action
   - Create Task
   - Subject: `Urgent Ticket Handling`
   - WhatId: ticket Id
   - Priority: High
   - Status: Not Started

9. Set `varAssignedTo`
   - High: `Senior Support Agent`
   - Otherwise: `Support Agent`

10. Optional SLA decision
    - Project specification gives an example of checking whether the Created Date is older than 2 days.

11. Set final message.

## Alternative

The repository also provides the Apex invocable action `Analyze Support Ticket Priority`. This can be used as the backend action for Agentforce instead of reproducing the same business logic in Flow.
