# Agentforce setup

Create a subagent/topic with:

## Name

Support Ticket Priority Analysis

## API name

Support_Ticket_Priority_Analysis

## Classification description

This topic analyzes customer support tickets to determine priority based on issue description and urgency. It handles requests related to ticket status, issue severity, and support prioritization.

## Scope

Only analyze support ticket descriptions, determine High/Medium/Low priority, and trigger backend automation for task assignment. Do not handle unrelated billing, subscription, or account-update requests.

## Instructions

1. Ask for Account Name if it is missing.
2. Retrieve the latest support ticket for the Account.
3. Read the ticket Description.
4. Determine priority:
   - High: `urgent`, `not working`, `failure`
   - Medium: `issue`, `slow`, `delay`
   - Low: none of the above.
5. Set/return the calculated priority.
6. For High priority, trigger the backend automation and ensure an urgent Task is created.
7. Return the assigned support level.
8. Return a clear user-facing message.
9. Do not send emails or directly perform unrelated record changes.

## Agent Action

Use the Apex invocable action:

`SupportTicketPriorityService.analyzeTicket`

Input:
- `accountName` / `varAccountName`

Outputs:
- `accountId`
- `ticketId`
- `priorityLevel`
- `assignedTo`
- `actionMessage`

Loading text:

`Analyzing ticket details and determining priority...`

The uploaded specification describes the same input/output concepts and Agentforce configuration.
