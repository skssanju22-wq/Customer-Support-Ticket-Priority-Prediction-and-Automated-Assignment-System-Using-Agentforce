# Test cases

| Test | Description | Expected |
|---|---|---|
| 1 | Description contains urgent | High |
| 2 | Description contains not working | High |
| 3 | Description contains failure | High |
| 4 | Description contains issue | Medium |
| 5 | Description contains slow | Medium |
| 6 | Description contains delay | Medium |
| 7 | No priority keyword | Low |
| 8 | High priority ticket | Urgent Task created |
| 9 | Unknown account | No matching account message |
| 10 | Blank account name | Account Name required message |

The Apex test class covers the main priority, task-creation, empty-input, and missing-account scenarios.
